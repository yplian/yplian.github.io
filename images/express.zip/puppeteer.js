const express = require('express');
const ssr = require('./ssr.js');
const puppeteer = require('puppeteer');

const app = express();
let browserWSEndpoint = null;

app.get('/', async (req, res, next) => {
    // console.log(req, res, next);
    if (!browserWSEndpoint) {
        const browser = await puppeteer.launch();
        browserWSEndpoint = await browser.wsEndpoint();
    }

    const url = req.originalUrl;
    const urlParams = url.split('?')[1];

    //  const {html, ttRenderMs} = await ssr(`${req.protocol}://${req.get('host')}/index.html`);
    const { html, ttRenderMs } = await ssr(urlParams,browserWSEndpoint);
    // Add Server-Timing! See https://w3c.github.io/server-timing/.
    res.set('Server-Timing', `Prerender;dur=${ttRenderMs};desc="Headless render time (ms)"`);
    return res.status(200).send(html); // Serve prerendered page as response.
});

app.listen(8080, () => console.log('http://localhost:8080/ Server started. Press Ctrl+C to quit'));