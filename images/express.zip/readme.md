# 使用

1. npm install
2. npm run test1
3. 打开浏览器，输入地址如 [http://localhost:8080/?https:baidu.com](http://localhost:8080/?https:baidu.com)
4. ?后面的为自定义地址
